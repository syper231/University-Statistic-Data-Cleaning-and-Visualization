```python
import numpy as np # linear algebra
import pandas as pd # data processing, CSV files
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime

```


```python
df = pd.read_csv('UoW_enrolment/waterloo-enrolement-2024.csv')
df.columns
```




    Index(['Fiscal Year', 'Term Type', 'Career', 'Program Level', 'Study Year',
           'Campus', 'Faculty (group)', 'Program Grouping', 'Coop Regular',
           'Work Term', 'Attendance', 'Visa Status', 'Student Headcounts'],
          dtype='object')




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 61953 entries, 0 to 61952
    Data columns (total 13 columns):
     #   Column              Non-Null Count  Dtype 
    ---  ------              --------------  ----- 
     0   Fiscal Year         61953 non-null  object
     1   Term Type           61953 non-null  object
     2   Career              61953 non-null  object
     3   Program Level       61953 non-null  object
     4   Study Year          61953 non-null  object
     5   Campus              61953 non-null  object
     6   Faculty (group)     61953 non-null  object
     7   Program Grouping    61953 non-null  object
     8   Coop Regular        61953 non-null  object
     9   Work Term           61953 non-null  object
     10  Attendance          61953 non-null  object
     11  Visa Status         61953 non-null  object
     12  Student Headcounts  61953 non-null  int64 
    dtypes: int64(1), object(12)
    memory usage: 6.1+ MB
    


```python
df.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fiscal Year</th>
      <th>Term Type</th>
      <th>Career</th>
      <th>Program Level</th>
      <th>Study Year</th>
      <th>Campus</th>
      <th>Faculty (group)</th>
      <th>Program Grouping</th>
      <th>Coop Regular</th>
      <th>Work Term</th>
      <th>Attendance</th>
      <th>Visa Status</th>
      <th>Student Headcounts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953</td>
      <td>61953.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>8</td>
      <td>3</td>
      <td>2</td>
      <td>6</td>
      <td>8</td>
      <td>6</td>
      <td>11</td>
      <td>146</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>2022/23</td>
      <td>Winter term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>4</td>
      <td>University of Waterloo</td>
      <td>ARTS</td>
      <td>Psychology</td>
      <td>Co-op</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>8186</td>
      <td>21229</td>
      <td>50695</td>
      <td>49516</td>
      <td>15137</td>
      <td>57019</td>
      <td>16514</td>
      <td>1912</td>
      <td>31316</td>
      <td>49828</td>
      <td>48740</td>
      <td>30413</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>13.879118</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>30.058838</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>12.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>552.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.sample(n=10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fiscal Year</th>
      <th>Term Type</th>
      <th>Career</th>
      <th>Program Level</th>
      <th>Study Year</th>
      <th>Campus</th>
      <th>Faculty (group)</th>
      <th>Program Grouping</th>
      <th>Coop Regular</th>
      <th>Work Term</th>
      <th>Attendance</th>
      <th>Visa Status</th>
      <th>Student Headcounts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1799</th>
      <td>2016/17</td>
      <td>Fall term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>3</td>
      <td>University of Waterloo</td>
      <td>SE</td>
      <td>Software Engineering</td>
      <td>Co-op</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian Permanent Resident</td>
      <td>9</td>
    </tr>
    <tr>
      <th>24680</th>
      <td>2019/20</td>
      <td>Spring term</td>
      <td>Graduate</td>
      <td>Masters</td>
      <td>M</td>
      <td>University of Waterloo</td>
      <td>ARTS</td>
      <td>Global Governance</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian</td>
      <td>19</td>
    </tr>
    <tr>
      <th>26521</th>
      <td>2019/20</td>
      <td>Spring term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>4</td>
      <td>University of Waterloo</td>
      <td>MATH</td>
      <td>Actuarial Science</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>International</td>
      <td>23</td>
    </tr>
    <tr>
      <th>9483</th>
      <td>2017/18</td>
      <td>Fall term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>4</td>
      <td>University of Waterloo</td>
      <td>MATH</td>
      <td>Statistics</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Part-Time</td>
      <td>Canadian</td>
      <td>3</td>
    </tr>
    <tr>
      <th>16273</th>
      <td>2018/19</td>
      <td>Fall term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>3</td>
      <td>University of Waterloo</td>
      <td>SCI</td>
      <td>Chemistry</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Part-Time</td>
      <td>International</td>
      <td>2</td>
    </tr>
    <tr>
      <th>33131</th>
      <td>2020/21</td>
      <td>Spring term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>2</td>
      <td>University of Waterloo</td>
      <td>ENV</td>
      <td>Geography and Aviation</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Part-Time</td>
      <td>Canadian</td>
      <td>17</td>
    </tr>
    <tr>
      <th>56484</th>
      <td>2023/24</td>
      <td>Fall term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>4</td>
      <td>University of Waterloo</td>
      <td>SCI</td>
      <td>Physics</td>
      <td>Co-op</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian Permanent Resident</td>
      <td>2</td>
    </tr>
    <tr>
      <th>33747</th>
      <td>2020/21</td>
      <td>Spring term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>3</td>
      <td>University of Waterloo</td>
      <td>ENV</td>
      <td>Environment and Resource Studies</td>
      <td>Co-op</td>
      <td>Work Term</td>
      <td>Full-Time</td>
      <td>International</td>
      <td>5</td>
    </tr>
    <tr>
      <th>313</th>
      <td>2016/17</td>
      <td>Fall term</td>
      <td>Graduate</td>
      <td>Masters</td>
      <td>M</td>
      <td>University of Waterloo</td>
      <td>ENV</td>
      <td>Geography</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Part-Time</td>
      <td>Canadian</td>
      <td>9</td>
    </tr>
    <tr>
      <th>10771</th>
      <td>2017/18</td>
      <td>Spring term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>3</td>
      <td>Renison University College</td>
      <td>ARTS</td>
      <td>Social Development Studies</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian Permanent Resident</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
columns = ['Fiscal Year', 'Term Type', 'Career', 'Program Level', 'Study Year', 'Campus', 'Coop Regular', 'Work Term', 'Attendance', 'Visa Status', 'Faculty (group)']

# Create an empty dictionary to store results
results = {}

for col in columns:
    results[col] = df[col].value_counts().sort_values()

for col, result in results.items():
    print(f"{col}:\n{result}\n")
```

    Fiscal Year:
    Fiscal Year
    2016/17    7165
    2017/18    7313
    2018/19    7395
    2019/20    7615
    2020/21    8044
    2023/24    8104
    2021/22    8131
    2022/23    8186
    Name: count, dtype: int64
    
    Term Type:
    Term Type
    Spring term    19644
    Fall term      21080
    Winter term    21229
    Name: count, dtype: int64
    
    Career:
    Career
    Graduate         11258
    Undergraduate    50695
    Name: count, dtype: int64
    
    Program Level:
    Program Level
    Qualifying       34
    Diploma         321
    Non-Degree     1238
    Doctoral       4393
    Masters        6451
    Bachelors     49516
    Name: count, dtype: int64
    
    Study Year:
    Study Year
    5      305
    N     1598
    D     4085
    1     6068
    M     6760
    2    13510
    3    14490
    4    15137
    Name: count, dtype: int64
    
    Campus:
    Campus
    Online                                 50
    Online - Renison                       54
    Conrad Grebel University College      102
    Renison University College           1354
    St. Jerome's University              3374
    University of Waterloo              57019
    Name: count, dtype: int64
    
    Coop Regular:
    Coop Regular
    Regular    30637
    Co-op      31316
    Name: count, dtype: int64
    
    Work Term:
    Work Term
    Work Term        12125
    Academic Term    49828
    Name: count, dtype: int64
    
    Attendance:
    Attendance
    Unknown Attendance       12
    Part-Time             13201
    Full-Time             48740
    Name: count, dtype: int64
    
    Visa Status:
    Visa Status
    Canadian Permanent Resident    14188
    International                  17352
    Canadian                       30413
    Name: count, dtype: int64
    
    Faculty (group):
    Faculty (group)
    SFM        41
    REN       107
    THL       143
    SE        429
    CFM       476
    HEA      4948
    ENV      5711
    ENG      8202
    SCI     11396
    MATH    13986
    ARTS    16514
    Name: count, dtype: int64
    
    

# Cleaning Process


```python
def convert_date(row):
    start = int(row.split('/')[0])
    return datetime(start,1,1)

def adjust_date(row):
    new_year = row['Fiscal Year'].year
    if row['Term Type'] == 'Winter term':
        new_month = 1 # january
        new_year += 1
    elif row['Term Type'] == 'Spring term':
        new_month = 5 # may
    elif row['Term Type'] == 'Fall term':
        new_month = 9 # september
    else:
        return row['Fiscal Year']
    return datetime(new_year, new_month, 1)

df['Fiscal Year'] = df['Fiscal Year'].apply(convert_date)
df['Fiscal Year'] = df.apply(adjust_date, axis=1)
df['Fiscal Year'] = pd.to_datetime(df['Fiscal Year']).dt.strftime('%Y-%m')
```


```python
df['Fiscal Year'].value_counts().sort_values()
```




    Fiscal Year
    2016-05    2223
    2017-05    2272
    2018-05    2335
    2019-05    2382
    2016-09    2461
    2017-01    2481
    2017-09    2502
    2018-09    2508
    2018-01    2539
    2019-01    2552
    2020-05    2569
    2023-05    2595
    2019-09    2600
    2022-05    2624
    2020-01    2633
    2021-05    2644
    2021-01    2734
    2021-09    2734
    2020-09    2741
    2022-01    2753
    2023-09    2754
    2024-01    2755
    2022-09    2780
    2023-01    2782
    Name: count, dtype: int64




```python
df = df.drop(df[df['Attendance'] == 'Unknown Attendance'].index)
df['Attendance'].value_counts().sort_values()
```




    Attendance
    Part-Time    13201
    Full-Time    48740
    Name: count, dtype: int64




```python
df.sample(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fiscal Year</th>
      <th>Term Type</th>
      <th>Career</th>
      <th>Program Level</th>
      <th>Study Year</th>
      <th>Campus</th>
      <th>Faculty (group)</th>
      <th>Program Grouping</th>
      <th>Coop Regular</th>
      <th>Work Term</th>
      <th>Attendance</th>
      <th>Visa Status</th>
      <th>Student Headcounts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>52016</th>
      <td>2023-01</td>
      <td>Winter term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>2</td>
      <td>University of Waterloo</td>
      <td>ARTS</td>
      <td>Religious Studies</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Part-Time</td>
      <td>Canadian</td>
      <td>1</td>
    </tr>
    <tr>
      <th>31662</th>
      <td>2020-09</td>
      <td>Fall term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>4</td>
      <td>University of Waterloo</td>
      <td>ARTS</td>
      <td>Legal Studies</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Part-Time</td>
      <td>International</td>
      <td>1</td>
    </tr>
    <tr>
      <th>45468</th>
      <td>2022-01</td>
      <td>Winter term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>4</td>
      <td>University of Waterloo</td>
      <td>SCI</td>
      <td>Biochemistry</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian</td>
      <td>23</td>
    </tr>
    <tr>
      <th>10407</th>
      <td>2017-05</td>
      <td>Spring term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>2</td>
      <td>University of Waterloo</td>
      <td>ENG</td>
      <td>Civil Engineering</td>
      <td>Co-op</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian</td>
      <td>84</td>
    </tr>
    <tr>
      <th>59717</th>
      <td>2024-01</td>
      <td>Winter term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>1</td>
      <td>St. Jerome's University</td>
      <td>ARTS</td>
      <td>Arts</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Part-Time</td>
      <td>Canadian</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29728</th>
      <td>2020-09</td>
      <td>Fall term</td>
      <td>Graduate</td>
      <td>Masters</td>
      <td>M</td>
      <td>University of Waterloo</td>
      <td>ARTS</td>
      <td>Peace and Conflict Studies</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian</td>
      <td>20</td>
    </tr>
    <tr>
      <th>59266</th>
      <td>2024-01</td>
      <td>Winter term</td>
      <td>Graduate</td>
      <td>Doctoral</td>
      <td>D</td>
      <td>University of Waterloo</td>
      <td>ENG</td>
      <td>Management Sciences</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>International</td>
      <td>17</td>
    </tr>
    <tr>
      <th>40927</th>
      <td>2021-05</td>
      <td>Spring term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>2</td>
      <td>Renison University College</td>
      <td>ARTS</td>
      <td>Arts</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>International</td>
      <td>1</td>
    </tr>
    <tr>
      <th>39717</th>
      <td>2021-09</td>
      <td>Fall term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>4</td>
      <td>University of Waterloo</td>
      <td>ARTS</td>
      <td>Sociology</td>
      <td>Co-op</td>
      <td>Work Term</td>
      <td>Full-Time</td>
      <td>International</td>
      <td>1</td>
    </tr>
    <tr>
      <th>31502</th>
      <td>2020-09</td>
      <td>Fall term</td>
      <td>Undergraduate</td>
      <td>Bachelors</td>
      <td>3</td>
      <td>University of Waterloo</td>
      <td>SCI</td>
      <td>Psychology</td>
      <td>Regular</td>
      <td>Academic Term</td>
      <td>Full-Time</td>
      <td>Canadian</td>
      <td>17</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.loc[df['Campus'] == 'Online', 'Campus'] = 'University of Waterloo'
df.loc[df['Campus'] == 'Online - Renison', 'Campus'] = 'Renison University College'
df['Campus'].value_counts().sort_values()
```




    Campus
    Conrad Grebel University College      102
    Renison University College           1408
    St. Jerome's University              3374
    University of Waterloo              57057
    Name: count, dtype: int64



## Visualization
1. Identify number of students each fiscal term
2. Number of students each faculty
3. Number of students from top 5 faculty and highest program


```python
fiscal_data = df.groupby('Fiscal Year')['Student Headcounts'].sum().sort_values(ascending=True)

plt.figure(figsize=(12,6))
ax = sns.barplot(x=fiscal_data.index, y=fiscal_data.values)
plt.title('Number of Student by Fiscal Year')
plt.ylabel('Number of Students')
plt.xlabel('Fiscal Years')

for bar, value in zip(ax.patches, fiscal_data.values):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 10, f'{value}', ha='center', va='bottom', rotation=50)

plt.xticks(rotation=75)

plt.show()
```


    
![png](output_13_0.png)
    



```python
faculty = df['Faculty (group)'].value_counts()
top_10 = faculty.sort_values()
plt.figure(figsize=(10,6))
bar = top_10.plot(kind='bar')
plt.xlabel('Faculty (group)')
plt.ylabel('Number of Students')

for i, v in enumerate(top_10):
    plt.text(i, v + 10, str(v), ha='center', va='bottom')

plt.tight_layout()
plt.show()
```


    
![png](output_14_0.png)
    



```python
faculty = df['Faculty (group)'].value_counts()
top_10 = faculty.sort_values(ascending=False).head(5)

# Sum the student counts for the top 5 faculties
total_students_top_5 = top_10.sum()

print("Total number of students in the top 5 faculties:", total_students_top_5)
```

    Total number of students in the top 5 faculties: 55797
    


```python
faculties = ['HEA', 'ENV', 'ENG', 'SCI', 'MATH', 'ARTS']

# Iterate over each faculty
for faculty in faculties:
    # Filter the DataFrame for the current faculty
    filtered_data = df[df['Faculty (group)'] == faculty]
    
    # Group by 'Program' and sum 'Student Headcounts', then sort in descending order
    program_data = filtered_data.groupby('Program Grouping')['Student Headcounts'].sum().sort_values(ascending=False)
    
    # Limit to top 10 programs
    program_data = program_data.head(10)
    
    # Create a bar plot for the current faculty
    plt.figure(figsize=(10, 6))
    ax = sns.barplot(x=program_data.values, y=program_data.index)
    plt.title(f'Top 10 Programs with Most Students in {faculty} Faculty')
    plt.xlabel('Number of Students')
    plt.ylabel('Program')
    plt.xticks(rotation=45)
    
    # Add numbers on top of each bar
    for bar, value in zip(ax.patches, program_data.values):
        ax.text(bar.get_width(), bar.get_y() + bar.get_height()/2, f'{value}', ha='left', va='center')
    
    plt.tight_layout()
    plt.show()
```


    
![png](output_16_0.png)
    



    
![png](output_16_1.png)
    



    
![png](output_16_2.png)
    



    
![png](output_16_3.png)
    



    
![png](output_16_4.png)
    



    
![png](output_16_5.png)
    



```python

```
